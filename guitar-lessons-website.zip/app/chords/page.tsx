"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Play, Pause, RotateCcw, Settings } from "lucide-react"

const sampleSong = {
  title: "Wonderwall - Oasis",
  lyrics: [
    { line: "Today is gonna be the day", chords: ["Em7", "", "G", ""] },
    { line: "That they're gonna throw it back to you", chords: ["", "D", "", "C"] },
    { line: "By now you should've somehow", chords: ["Em7", "", "G", ""] },
    { line: "Realized what you gotta do", chords: ["", "D", "", "C"] },
    { line: "I don't believe that anybody", chords: ["Em7", "", "G", "D"] },
    { line: "Feels the way I do about you now", chords: ["", "C", "", ""] },
  ],
}

export default function ChordsPage() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentLine, setCurrentLine] = useState(0)
  const [scrollSpeed, setScrollSpeed] = useState(2000)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setCurrentLine((prev) => {
          if (prev >= sampleSong.lyrics.length - 1) {
            setIsPlaying(false)
            return 0
          }
          return prev + 1
        })
      }, scrollSpeed)
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isPlaying, scrollSpeed])

  const togglePlayback = () => {
    setIsPlaying(!isPlaying)
  }

  const resetSong = () => {
    setIsPlaying(false)
    setCurrentLine(0)
  }

  return (
    <div className="pt-20 min-h-screen bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-amber-400 mb-4">Guitar Chords & Tabs</h1>
          <p className="text-gray-300 text-lg">Interactive chord charts with auto-scroll functionality</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="bg-black/50 border-amber-900/30 mb-6">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-amber-400 text-2xl">{sampleSong.title}</CardTitle>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Settings className="w-4 h-4 text-gray-400" />
                    <select
                      value={scrollSpeed}
                      onChange={(e) => setScrollSpeed(Number(e.target.value))}
                      className="bg-gray-800 text-white border border-gray-600 rounded px-2 py-1 text-sm"
                    >
                      <option value={1000}>Fast</option>
                      <option value={2000}>Normal</option>
                      <option value={3000}>Slow</option>
                    </select>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={resetSong}
                    className="border-amber-400 text-amber-400 hover:bg-amber-400 hover:text-black bg-transparent"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                  <Button onClick={togglePlayback} className="bg-amber-500 hover:bg-amber-600 text-black">
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent>
              <div className="chord-tab p-6 rounded-lg">
                {sampleSong.lyrics.map((lyricLine, index) => (
                  <div
                    key={index}
                    className={`mb-6 transition-all duration-300 ${
                      index === currentLine ? "bg-amber-900/30 p-3 rounded" : ""
                    }`}
                  >
                    {/* Chord line */}
                    <div className="flex text-amber-400 font-bold mb-1 text-lg">
                      {lyricLine.chords.map((chord, chordIndex) => (
                        <span key={chordIndex} className="inline-block min-w-[80px] text-center">
                          {chord}
                        </span>
                      ))}
                    </div>

                    {/* Lyrics line */}
                    <div className="text-white text-lg font-mono">{lyricLine.line}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Chord Dictionary */}
          <Card className="bg-black/50 border-amber-900/30">
            <CardHeader>
              <CardTitle className="text-amber-400">Chord Dictionary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {["Em7", "G", "D", "C"].map((chord) => (
                  <div key={chord} className="text-center p-4 bg-gray-800 rounded-lg">
                    <h3 className="text-amber-400 font-bold mb-2">{chord}</h3>
                    <div className="text-xs text-gray-400">
                      <div>e|---3---</div>
                      <div>B|---3---</div>
                      <div>G|---0---</div>
                      <div>D|---2---</div>
                      <div>A|---2---</div>
                      <div>E|---0---</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
