"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Save, Eye, Plus } from "lucide-react"

export default function AdminPage() {
  const [songTitle, setSongTitle] = useState("")
  const [lyrics, setLyrics] = useState("")
  const [chordedLyrics, setChordedLyrics] = useState<Array<{ line: string; chords: string[] }>>([])
  const [selectedText, setSelectedText] = useState("")
  const [selectedChord, setSelectedChord] = useState("")

  const commonChords = [
    "C",
    "D",
    "E",
    "F",
    "G",
    "A",
    "B",
    "Em",
    "Am",
    "Dm",
    "Fm",
    "Gm",
    "C7",
    "D7",
    "E7",
    "F7",
    "G7",
    "A7",
    "B7",
  ]

  const handleTextSelection = () => {
    const selection = window.getSelection()
    if (selection && selection.toString()) {
      setSelectedText(selection.toString())
    }
  }

  const addChordToSelection = (chord: string) => {
    if (selectedText) {
      // This is a simplified version - in a real app, you'd need more sophisticated text processing
      console.log(`Adding chord ${chord} to text: ${selectedText}`)
      setSelectedChord(chord)
    }
  }

  const processLyrics = () => {
    const lines = lyrics.split("\n").filter((line) => line.trim())
    const processed = lines.map((line) => ({
      line: line.trim(),
      chords: ["", "", "", ""], // Placeholder chord positions
    }))
    setChordedLyrics(processed)
  }

  const saveSong = () => {
    const songData = {
      title: songTitle,
      lyrics: chordedLyrics,
    }
    // Here you would send to your Flask backend
    console.log("Saving song:", songData)
    alert("Song saved successfully!")
  }

  return (
    <div className="pt-20 min-h-screen bg-gradient-to-b from-gray-900 to-black">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-amber-400 mb-4">Admin Panel</h1>
          <p className="text-gray-300 text-lg">Add songs and manage chord placements</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <div className="space-y-6">
            <Card className="bg-black/50 border-amber-900/30">
              <CardHeader>
                <CardTitle className="text-amber-400">Song Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <input
                  type="text"
                  placeholder="Song Title"
                  value={songTitle}
                  onChange={(e) => setSongTitle(e.target.value)}
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-600 rounded-lg focus:border-amber-400 focus:outline-none text-white"
                />

                <textarea
                  placeholder="Paste lyrics here..."
                  value={lyrics}
                  onChange={(e) => setLyrics(e.target.value)}
                  onMouseUp={handleTextSelection}
                  rows={10}
                  className="w-full px-4 py-2 bg-gray-800 border border-gray-600 rounded-lg focus:border-amber-400 focus:outline-none text-white resize-none"
                />

                <Button onClick={processLyrics} className="w-full bg-amber-500 hover:bg-amber-600 text-black">
                  <Plus className="w-4 h-4 mr-2" />
                  Process Lyrics
                </Button>
              </CardContent>
            </Card>

            {/* Chord Palette */}
            <Card className="bg-black/50 border-amber-900/30">
              <CardHeader>
                <CardTitle className="text-amber-400">Chord Palette</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-2">
                  {commonChords.map((chord) => (
                    <Button
                      key={chord}
                      variant="outline"
                      size="sm"
                      onClick={() => addChordToSelection(chord)}
                      className="border-amber-400 text-amber-400 hover:bg-amber-400 hover:text-black"
                    >
                      {chord}
                    </Button>
                  ))}
                </div>

                {selectedText && (
                  <div className="mt-4 p-3 bg-gray-800 rounded-lg">
                    <p className="text-sm text-gray-400 mb-2">Selected text:</p>
                    <p className="text-white font-mono">"{selectedText}"</p>
                    {selectedChord && <p className="text-amber-400 text-sm mt-2">Chord: {selectedChord}</p>}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Preview Section */}
          <div>
            <Card className="bg-black/50 border-amber-900/30">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-amber-400">Preview</CardTitle>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-amber-400 text-amber-400 hover:bg-amber-400 hover:text-black bg-transparent"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Preview
                  </Button>
                  <Button onClick={saveSong} size="sm" className="bg-amber-500 hover:bg-amber-600 text-black">
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                </div>
              </CardHeader>

              <CardContent>
                {songTitle && <h3 className="text-xl font-bold text-amber-400 mb-4">{songTitle}</h3>}

                <div className="chord-tab p-4 rounded-lg max-h-96 overflow-y-auto">
                  {chordedLyrics.length > 0 ? (
                    chordedLyrics.map((lyricLine, index) => (
                      <div key={index} className="mb-4">
                        <div className="flex text-amber-400 font-bold mb-1">
                          {lyricLine.chords.map((chord, chordIndex) => (
                            <span key={chordIndex} className="inline-block min-w-[60px] text-center text-sm">
                              {chord}
                            </span>
                          ))}
                        </div>
                        <div className="text-white font-mono text-sm">{lyricLine.line}</div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-400 text-center py-8">Process lyrics to see preview</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
