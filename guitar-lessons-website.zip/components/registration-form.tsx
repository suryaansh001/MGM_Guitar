"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { X, User, Mail, Phone, Calendar } from "lucide-react"

interface RegistrationFormProps {
  isOpen: boolean
  onClose: () => void
  workshopTitle?: string
}

export function RegistrationForm({ isOpen, onClose, workshopTitle = "Guitar Workshop" }: RegistrationFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    experience: "",
    preferredDate: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission - would connect to Flask backend
    console.log("Form submitted:", formData)
    alert("Registration submitted successfully!")
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md bg-gray-900 border-amber-900/30">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-amber-400">Register for {workshopTitle}</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <User className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Full Name"
                className="w-full pl-10 pr-4 py-2 bg-black/50 border border-gray-600 rounded-lg focus:border-amber-400 focus:outline-none text-white"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="relative">
              <Mail className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <input
                type="email"
                placeholder="Email Address"
                className="w-full pl-10 pr-4 py-2 bg-black/50 border border-gray-600 rounded-lg focus:border-amber-400 focus:outline-none text-white"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>

            <div className="relative">
              <Phone className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <input
                type="tel"
                placeholder="Phone Number"
                className="w-full pl-10 pr-4 py-2 bg-black/50 border border-gray-600 rounded-lg focus:border-amber-400 focus:outline-none text-white"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>

            <select
              className="w-full px-4 py-2 bg-black/50 border border-gray-600 rounded-lg focus:border-amber-400 focus:outline-none text-white"
              value={formData.experience}
              onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
              required
            >
              <option value="">Select Experience Level</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>

            <div className="relative">
              <Calendar className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <input
                type="date"
                className="w-full pl-10 pr-4 py-2 bg-black/50 border border-gray-600 rounded-lg focus:border-amber-400 focus:outline-none text-white"
                value={formData.preferredDate}
                onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                required
              />
            </div>

            <textarea
              placeholder="Additional Message (Optional)"
              rows={3}
              className="w-full px-4 py-2 bg-black/50 border border-gray-600 rounded-lg focus:border-amber-400 focus:outline-none text-white resize-none"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
            />

            <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-black font-semibold">
              Submit Registration
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
