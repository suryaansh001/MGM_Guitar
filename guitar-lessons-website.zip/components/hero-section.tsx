"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, Environment } from "@react-three/drei"
import { Button } from "@/components/ui/button"
import { Play, Music } from "lucide-react"

function Guitar3D() {
  return (
    <group>
      {/* Guitar body */}
      <mesh position={[0, 0, 0]} rotation={[0, 0, 0.1]}>
        <boxGeometry args={[2, 3, 0.3]} />
        <meshStandardMaterial color="#8B4513" />
      </mesh>

      {/* Guitar neck */}
      <mesh position={[0, 2, 0]} rotation={[0, 0, 0.1]}>
        <boxGeometry args={[0.4, 2, 0.2]} />
        <meshStandardMaterial color="#654321" />
      </mesh>

      {/* Strings */}
      {Array.from({ length: 6 }, (_, i) => (
        <mesh key={i} position={[-0.15 + i * 0.06, 1, 0.11]} rotation={[0, 0, 0.1]}>
          <cylinderGeometry args={[0.002, 0.002, 4]} />
          <meshStandardMaterial color="#C0C0C0" />
        </mesh>
      ))}
    </group>
  )
}

export function HeroSection() {
  return (
    <section className="relative h-screen flex items-center justify-center metallic-texture chrome-effect">
      <div className="absolute inset-0 bg-black/60" />

      <div className="container mx-auto px-4 z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-5xl lg:text-7xl font-bold mb-6 bg-gradient-to-r from-white via-gray-300 to-blue-400 bg-clip-text text-transparent">
              Master the Guitar
            </h1>
            <p className="text-xl lg:text-2xl text-gray-300 mb-8 leading-relaxed">
              Learn from a professional guitarist with 15+ years of experience. From beginner chords to advanced
              techniques.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white font-semibold metallic-shine"
              >
                <Play className="w-5 h-5 mr-2" />
                Start Learning
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-black bg-transparent glass-effect"
              >
                <Music className="w-5 h-5 mr-2" />
                View Workshops
              </Button>
            </div>
          </div>

          <div className="h-96 lg:h-[500px]">
            <Canvas camera={{ position: [0, 0, 8], fov: 50 }}>
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} />
              <Guitar3D />
              <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={2} />
              <Environment preset="studio" />
            </Canvas>
          </div>
        </div>
      </div>
    </section>
  )
}
